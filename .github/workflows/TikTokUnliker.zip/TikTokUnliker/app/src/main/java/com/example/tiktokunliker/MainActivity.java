package com.example.tiktokunliker;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String START_URL = "https://www.tiktok.com/";
    private static final Pattern VIDEO_URL =
            Pattern.compile("^https?://[^/]*tiktok\\.com/@[^/]+/(?:video|photo)/\\d+");
    private static final long ITEM_TIMEOUT_MS = 30000;

    private WebView web;
    private WebView worker;
    private TextView status;
    private Button btnMode;
    private Button btnUnlike;
    private Button btnDesktop;

    private boolean selectMode = false;
    private boolean desktop = true;
    private String mobileUa = "";
    private String desktopUa = "";
    private final LinkedHashSet<String> selected = new LinkedHashSet<>();
    private String injectScript = "";
    private String unlikeScript = "";

    // Unlike queue state
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final ArrayList<String> queue = new ArrayList<>();
    private boolean running = false;
    private boolean itemHandled = false;
    private int qIndex = 0;
    private int okCount = 0;
    private int alreadyCount = 0;
    private int unconfirmedCount = 0;
    private int failedCount = 0;
    private int failStreak = 0;
    private Runnable timeoutTask;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        injectScript = readAsset("inject.js");
        unlikeScript = readAsset("unlike.js");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        status = new TextView(this);
        status.setBackgroundColor(Color.parseColor("#FE2C55"));
        status.setTextColor(Color.WHITE);
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        status.setPadding(24, 16, 24, 16);
        status.setVisibility(View.GONE);
        root.addView(status, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        worker = new WebView(this);
        worker.setVisibility(View.GONE);
        root.addView(worker, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.parseColor("#161823"));
        bar.setPadding(8, 8, 8, 8);
        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        btnMode = makeButton(bar, "Select: OFF");
        Button btnAdd = makeButton(bar, "+ Video");
        btnUnlike = makeButton(bar, "Unlike (0)");
        Button btnClear = makeButton(bar, "Clear");
        btnDesktop = makeButton(bar, "PC: ON");

        btnMode.setOnClickListener(v -> {
            if (blocked()) return;
            selectMode = !selectMode;
            refresh();
            if (selectMode) {
                Toast.makeText(this, "Tap liked videos to select them", Toast.LENGTH_SHORT).show();
            }
        });

        btnAdd.setOnClickListener(v -> {
            if (blocked()) return;
            String url = normalize(web.getUrl());
            if (url == null) {
                Toast.makeText(this, "Open a single video first", Toast.LENGTH_SHORT).show();
                return;
            }
            if (selected.add(url)) {
                Toast.makeText(this, "Added", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Already selected", Toast.LENGTH_SHORT).show();
            }
            refresh();
        });

        btnUnlike.setOnClickListener(v -> {
            if (running) {
                finishRun("Stopped", false);
            } else {
                confirmRun();
            }
        });

        btnClear.setOnClickListener(v -> {
            if (blocked()) return;
            selected.clear();
            refresh();
        });

        btnDesktop.setOnClickListener(v -> {
            if (blocked()) return;
            desktop = !desktop;
            applyBrowserMode();
            refresh();
            web.reload();
        });

        setContentView(root);

        // Main browser
        configure(web);
        WebSettings s = web.getSettings();
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);

        String def = s.getUserAgentString();
        mobileUa = def.replace("; wv", "").replaceAll("Version/\\d+\\.\\d+ ", "");
        Matcher chromeMatcher = Pattern.compile("Chrome/([\\d.]+)").matcher(def);
        String chrome = chromeMatcher.find() ? chromeMatcher.group(1) : "130.0.0.0";
        desktopUa = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                + "(KHTML, like Gecko) Chrome/" + chrome + " Safari/537.36";
        applyBrowserMode();

        web.addJavascriptInterface(new Bridge(), "TTBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request.getUrl().toString();
                return !(u.startsWith("http://") || u.startsWith("https://"));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                injectAll();
            }

            @Override
            public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
                injectAll();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        WebResourceError error) {
                if (request.isForMainFrame()) {
                    Toast.makeText(MainActivity.this,
                            "Page error: " + error.getDescription(), Toast.LENGTH_LONG).show();
                }
            }
        });

        // Background browser that removes the likes (always desktop, silent)
        configure(worker);
        WebSettings ws = worker.getSettings();
        ws.setUserAgentString(desktopUa);
        ws.setUseWideViewPort(true);
        ws.setLoadWithOverviewMode(true);
        ws.setMediaPlaybackRequiresUserGesture(true);

        worker.addJavascriptInterface(new WorkerBridge(), "TTWorker");
        worker.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request.getUrl().toString();
                return !(u.startsWith("http://") || u.startsWith("https://"));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (running && url != null && url.startsWith("http")) {
                    view.evaluateJavascript(unlikeScript, null);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        WebResourceError error) {
                if (running && request.isForMainFrame()) {
                    itemDone("notfound");
                }
            }
        });

        if (savedInstanceState == null) {
            web.loadUrl(START_URL);
        } else {
            web.restoreState(savedInstanceState);
        }
        refresh();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configure(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(w, true);
    }

    private void applyBrowserMode() {
        WebSettings s = web.getSettings();
        if (desktop) {
            s.setUserAgentString(desktopUa);
            s.setUseWideViewPort(true);
            s.setLoadWithOverviewMode(true);
        } else {
            s.setUserAgentString(mobileUa);
            s.setUseWideViewPort(false);
            s.setLoadWithOverviewMode(false);
        }
    }

    private Button makeButton(LinearLayout bar, String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        b.setSingleLine(true);
        b.setPadding(4, 0, 4, 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(3, 0, 3, 0);
        bar.addView(b, lp);
        return b;
    }

    private boolean blocked() {
        if (running) {
            Toast.makeText(this, "Busy removing likes. Tap Stop first.", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    // ---------- Unlike queue ----------

    private void confirmRun() {
        if (selected.isEmpty()) {
            Toast.makeText(this, "Nothing selected", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Remove " + selected.size() + " like(s)?")
                .setMessage("Each selected video is opened in the background and its like is "
                        + "removed, one by one with short pauses. Keep the app open until it "
                        + "finishes. You can stop at any time.")
                .setPositiveButton("Unlike", (d, w) -> beginRun())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void beginRun() {
        queue.clear();
        queue.addAll(selected);
        qIndex = 0;
        okCount = 0;
        alreadyCount = 0;
        unconfirmedCount = 0;
        failedCount = 0;
        failStreak = 0;
        running = true;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        status.setOnClickListener(null);
        status.setVisibility(View.VISIBLE);
        web.setVisibility(View.GONE);
        worker.setVisibility(View.VISIBLE);
        refresh();
        loadCurrent();
    }

    private void loadCurrent() {
        if (!running || qIndex >= queue.size()) return;
        itemHandled = false;
        updateStatus();
        timeoutTask = () -> itemDone("timeout");
        handler.postDelayed(timeoutTask, ITEM_TIMEOUT_MS);
        worker.loadUrl(queue.get(qIndex));
    }

    private void updateStatus() {
        status.setText("Removing like " + Math.min(qIndex + 1, queue.size()) + " of "
                + queue.size() + "  |  done " + (okCount + alreadyCount)
                + "  |  failed " + failedCount);
    }

    private void itemDone(String result) {
        if (!running || itemHandled || qIndex >= queue.size()) return;
        itemHandled = true;
        if (timeoutTask != null) handler.removeCallbacks(timeoutTask);

        String url = queue.get(qIndex);
        switch (result) {
            case "unliked":
                okCount++;
                selected.remove(url);
                failStreak = 0;
                break;
            case "notliked":
                alreadyCount++;
                selected.remove(url);
                failStreak = 0;
                break;
            case "unverified":
                unconfirmedCount++;
                failStreak = 0;
                break;
            default:
                failedCount++;
                failStreak++;
                break;
        }
        qIndex++;
        refresh();

        if (failStreak >= 3) {
            finishRun("Stopped after 3 failures in a row", true);
            return;
        }
        if (qIndex >= queue.size()) {
            finishRun("Finished", false);
            return;
        }
        updateStatus();
        handler.postDelayed(this::loadCurrent, 3000 + rnd.nextInt(3500));
    }

    private void finishRun(String title, boolean offerView) {
        running = false;
        handler.removeCallbacksAndMessages(null);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        worker.stopLoading();
        refresh();

        String msg = "Unliked: " + okCount + "\nAlready not liked: " + alreadyCount;
        if (unconfirmedCount > 0) {
            msg += "\nNot confirmed (kept selected, run again to check): " + unconfirmedCount;
        }
        if (failedCount > 0) {
            msg += "\nFailed (kept selected): " + failedCount;
        }
        if (offerView) {
            msg += "\n\nTikTok may be showing a captcha or login prompt. Tap \"View page\" "
                    + "to look.";
        }

        if (okCount + alreadyCount > 0) {
            web.reload();
        }

        if (isFinishing()) return;
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton("Close", (d, w) -> hideWorker())
                .setOnCancelListener(d -> hideWorker());
        if (offerView) {
            b.setNeutralButton("View page", (d, w) -> {
                status.setText("Tap here to close this view");
                status.setOnClickListener(v -> hideWorker());
            });
        }
        b.show();
    }

    private void hideWorker() {
        worker.setVisibility(View.GONE);
        worker.loadUrl("about:blank");
        status.setVisibility(View.GONE);
        status.setOnClickListener(null);
        web.setVisibility(View.VISIBLE);
    }

    // ---------- Selection in the main browser ----------

    private void injectAll() {
        if (web == null) return;
        web.evaluateJavascript(injectScript, null);
        pushState();
    }

    private void pushState() {
        StringBuilder json = new StringBuilder("[");
        boolean first = true;
        for (String link : selected) {
            if (!first) json.append(',');
            first = false;
            json.append('"').append(link.replace("\\", "\\\\").replace("\"", "\\\"")).append('"');
        }
        json.append(']');
        web.evaluateJavascript(
                "if(window.__ttSetMode){window.__ttSetDesktop(" + desktop + ");"
                        + "window.__ttSetMode(" + selectMode + ");"
                        + "window.__ttSet(" + json + ");}", null);
    }

    private void refresh() {
        btnMode.setText(selectMode ? "Select: ON" : "Select: OFF");
        btnUnlike.setText(running ? "Stop" : "Unlike (" + selected.size() + ")");
        btnDesktop.setText(desktop ? "PC: ON" : "PC: OFF");
        pushState();
    }

    private static String normalize(String url) {
        if (url == null) return null;
        Matcher m = VIDEO_URL.matcher(url);
        return m.find() ? m.group() : null;
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return out.toString("UTF-8");
        } catch (IOException e) {
            return "";
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (worker != null) worker.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (running) {
            finishRun("Stopped", false);
        } else if (worker.getVisibility() == View.VISIBLE) {
            hideWorker();
        } else if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private class Bridge {
        @JavascriptInterface
        public void toggle(String url) {
            final String u = normalize(url);
            if (u == null) return;
            runOnUiThread(() -> {
                if (running) return;
                if (!selected.remove(u)) {
                    selected.add(u);
                }
                refresh();
            });
        }
    }

    private class WorkerBridge {
        @JavascriptInterface
        public void result(String r) {
            final String res = r;
            runOnUiThread(() -> itemDone(res));
        }
    }
}
