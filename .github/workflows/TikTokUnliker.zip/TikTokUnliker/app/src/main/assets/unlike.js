(function () {
  if (window.__ttUnlikeRun) { return; }
  window.__ttUnlikeRun = true;
  window.__ttFinished = false;

  var SEL = '[data-e2e="like-icon"], [data-e2e="browse-like-icon"]';
  var started = Date.now();
  var clicked = false;
  var clickedAt = 0;

  // Desktop layout needs a wide viewport
  var vp = document.querySelector('meta[name="viewport"]');
  if (!vp) {
    vp = document.createElement('meta');
    vp.setAttribute('name', 'viewport');
    (document.head || document.documentElement).appendChild(vp);
  }
  vp.setAttribute('content', 'width=1100');

  function done(s) {
    if (window.__ttFinished) { return; }
    window.__ttFinished = true;
    TTWorker.result(s);
  }

  function quiet() {
    var vs = document.querySelectorAll('video');
    for (var i = 0; i < vs.length; i++) {
      try { vs[i].muted = true; vs[i].pause(); } catch (e) {}
    }
  }

  function btnOf(icon) {
    return icon.closest('button') || icon.closest('[role="button"]') || icon;
  }

  function isRed(color) {
    var m = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(color || '');
    return !!m && +m[1] > 200 && +m[2] < 110 && +m[3] < 130;
  }

  // true = liked, false = not liked, null = can't tell
  function likedState(btn, icon) {
    var p = btn.getAttribute('aria-pressed');
    if (p === 'true') { return true; }
    if (p === 'false') { return false; }
    var nodes = [icon];
    var kids = icon.querySelectorAll('svg, svg *');
    for (var i = 0; i < kids.length; i++) { nodes.push(kids[i]); }
    var seenColor = false;
    for (var j = 0; j < nodes.length; j++) {
      var cs = getComputedStyle(nodes[j]);
      if (isRed(cs.fill) || isRed(cs.color)) { return true; }
      if (/rgb/.test(cs.fill || '')) { seenColor = true; }
    }
    return seenColor ? false : null;
  }

  function tick() {
    if (window.__ttFinished) { return; }
    quiet();
    var icon = document.querySelector(SEL);
    if (icon) {
      var btn = btnOf(icon);
      var st = likedState(btn, icon);
      if (!clicked) {
        if (st === true) {
          // Only ever click when the video is confirmed liked, so we can never add a like by mistake
          clicked = true;
          clickedAt = Date.now();
          btn.click();
        } else if (st === false) {
          done('notliked');
          return;
        } else if (Date.now() - started > 8000) {
          done('unknown');
          return;
        }
      } else {
        if (likedState(btn, icon) === false) { done('unliked'); return; }
        if (Date.now() - clickedAt > 5000) { done('unverified'); return; }
      }
    } else if (Date.now() - started > 15000) {
      done('notfound');
      return;
    }
    setTimeout(tick, 500);
  }

  setTimeout(tick, 1500);
})();
