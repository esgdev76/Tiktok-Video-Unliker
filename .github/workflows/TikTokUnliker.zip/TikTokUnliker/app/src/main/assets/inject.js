(function () {
  if (window.__ttInit) { return; }
  window.__ttInit = true;
  window.__ttSel = {};
  window.__ttMode = false;
  window.__ttDesktop = false;

  var RE = /^(https?:\/\/[^\/]*tiktok\.com\/@[^\/]+\/(?:video|photo)\/\d+)/;
  var LINKS = 'a[href*="/video/"], a[href*="/photo/"]';

  var style = document.createElement('style');
  style.textContent =
    'html.tt-mode a[href*="/video/"], html.tt-mode a[href*="/photo/"]{box-shadow:inset 0 0 0 2px rgba(254,44,85,.55);}' +
    'a[data-tt-sel="1"]{position:relative !important;outline:5px solid #fe2c55 !important;outline-offset:-5px;opacity:.65 !important;}' +
    'a[data-tt-sel="1"]::after{content:"\\2713";position:absolute;top:6px;right:6px;width:26px;height:26px;' +
    'line-height:26px;text-align:center;border-radius:50%;background:#fe2c55;color:#fff;' +
    'font:bold 16px sans-serif;z-index:99999;}';
  (document.head || document.documentElement).appendChild(style);

  function linkOf(a) {
    if (a && a.tagName === 'A' && a.href) {
      var m = RE.exec(a.href);
      if (m) { return m[1]; }
    }
    return null;
  }

  // Finds the video link for a tapped element: first an enclosing link,
  // then a container that holds exactly one video link.
  function findLink(el) {
    var n = el;
    while (n && n !== document) {
      var u = linkOf(n);
      if (u) { return u; }
      n = n.parentNode;
    }
    n = el;
    for (var depth = 0; n && n !== document.body && n !== document && depth < 6; depth++) {
      if (n.querySelectorAll) {
        var as = n.querySelectorAll(LINKS);
        var found = null, count = 0;
        for (var i = 0; i < as.length; i++) {
          var l = linkOf(as[i]);
          if (l && l !== found) { found = l; count++; }
        }
        if (count === 1) { return found; }
        if (count > 1) { return null; }
      }
      n = n.parentNode;
    }
    return null;
  }

  function mark() {
    var as = document.querySelectorAll(LINKS);
    for (var i = 0; i < as.length; i++) {
      var u = linkOf(as[i]);
      if (u && window.__ttSel[u]) {
        as[i].setAttribute('data-tt-sel', '1');
      } else {
        as[i].removeAttribute('data-tt-sel');
      }
    }
  }

  function ensureViewport() {
    if (!window.__ttDesktop) { return; }
    var m = document.querySelector('meta[name="viewport"]');
    if (!m) {
      m = document.createElement('meta');
      m.setAttribute('name', 'viewport');
      (document.head || document.documentElement).appendChild(m);
    }
    if (m.getAttribute('content') !== 'width=1100') {
      m.setAttribute('content', 'width=1100');
    }
  }

  // In select mode, keep the site from reacting to presses on videos
  ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'touchstart', 'touchend'].forEach(function (t) {
    document.addEventListener(t, function (e) {
      if (!window.__ttMode) { return; }
      if (findLink(e.target)) {
        e.stopPropagation();
        e.stopImmediatePropagation();
      }
    }, { capture: true, passive: true });
  });

  document.addEventListener('click', function (e) {
    if (!window.__ttMode) { return; }
    var url = findLink(e.target);
    if (!url) { return; }
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    TTBridge.toggle(url);
  }, true);

  window.__ttSet = function (list) {
    var s = {};
    for (var i = 0; i < list.length; i++) { s[list[i]] = 1; }
    window.__ttSel = s;
    mark();
  };

  window.__ttSetMode = function (on) {
    window.__ttMode = !!on;
    document.documentElement.classList.toggle('tt-mode', !!on);
  };

  window.__ttSetDesktop = function (on) {
    window.__ttDesktop = !!on;
    ensureViewport();
  };

  var timer = null;
  new MutationObserver(function () {
    if (timer) { return; }
    timer = setTimeout(function () { timer = null; ensureViewport(); mark(); }, 400);
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
