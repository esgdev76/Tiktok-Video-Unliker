# TikTok Unliker

An Android app for removing likes from your own TikTok account in bulk. Log in to TikTok inside the app, switch on Select mode, tap all the liked videos you want to get rid of (without opening them), then press **Unlike**. The app removes the likes for you, one video at a time.

> **Unofficial.** Not affiliated with, endorsed by, or connected to TikTok or ByteDance. Personal-use tool that works inside your own logged-in session.

## Features

- Built-in TikTok browser with normal login.
- **Select mode:** tapping a video selects it instead of opening it. Selected videos get a red outline and a check mark.
- **Bulk unlike:** removes the like from every selected video automatically.
- **PC mode on/off switch** (on by default): uses the desktop site so search and the Liked tab work properly and the "Open TikTok app" popup disappears.
- **Safe by design:** it only presses the heart when the video is confirmed as liked, so it can never add a like by accident.
- **Human-like pace:** a few seconds' pause between videos, automatic stop after 3 failures in a row (for example a captcha).
- **Progress and summary:** shows how far it is and finishes with a report of unliked, already-not-liked and failed videos. Failed ones stay selected so you can retry.
- **Stop any time** with the same button.

## How to use

| Button | What it does |
|---|---|
| **Select: OFF / ON** | Selection mode. While ON, tapping a video selects it instead of opening it. |
| **+ Video** | Adds the video you currently have open. |
| **Unlike (n)** | Removes the like from all *n* selected videos (asks to confirm). Turns into **Stop** while running. |
| **Clear** | Empties the selection. |
| **PC: ON / OFF** | Switches between desktop and mobile TikTok. |

1. Log in to TikTok.
2. Open your profile and the **Liked** tab.
3. Turn **Select** ON and tap the videos you want to unlike.
4. Tap **Unlike (n)** and confirm.
5. Wait for the summary. The Liked list reloads afterwards.

Tip: try it with 1-2 videos first, then do bigger batches.

## How it works

TikTok only offers the heart button on a video's own page, so the app works through the selection as a queue:

1. In the main browser, an injected script (`inject.js`) catches taps on video thumbnails in Select mode and reports their links to the app.
2. On **Unlike**, a second, hidden desktop browser opens each selected video in turn. It shares the same login.
3. A script (`unlike.js`) waits for the heart button, reads whether the video is liked (`aria-pressed`, with a colour check as fallback), clicks it only if it is liked, then confirms the state changed.
4. The result is sent back to the app, the video leaves the selection, and the next one starts after a short random pause.
5. After 3 consecutive failures the run stops and offers to show the page, so you can solve a captcha or log in again.

## Privacy

No analytics, ads or servers. The app only talks to TikTok's website. Only the `INTERNET` permission is used. Your login is handled by TikTok's own page.

## Install

1. Create a repository and upload `TikTokUnliker.zip` (and the workflow file `.github/workflows/build.yml` from the zip's contents, see below).
2. Open **Actions → Build APK** and wait for the green check.
3. Download the **TikTokUnliker-apk** artifact, unzip it and install `app-debug.apk`.

Or open the project in Android Studio and use **Build → Build APK(s)**.

## Requirements

Android 7.0+ (API 24), up-to-date Android System WebView, internet connection, a TikTok account.

## Known limitations

- TikTok changes its website often. If unliking stops working after a site update, the heart-button detection in `unlike.js` may need adjusting.
- Google/Apple sign-in may be blocked inside embedded browsers; email, phone or QR login is more likely to work.
- Many actions in a short time can trigger captchas or temporary limits from TikTok. Use moderate batches.
- Keep the app open and the screen on while it runs.
- Debug build only.

## Disclaimer

Use at your own risk and respect TikTok's Terms of Service. Removed likes cannot be restored in bulk.
